# Changelog

Every released version of Scriare, newest first.

Entries are one or two sentences. The reasoning behind the bigger decisions
is in [CASE_STUDY.md](CASE_STUDY.md); the long-form notes each release was
originally written with are preserved in this file's history.

Versions are not dated — the project was built in a continuous run rather
than on a release schedule, and inventing dates would be worse than
omitting them.

---

## v0.51.0 — Where the time actually goes

The audit's tier 3. Measured first, and the measurement is most of what
this release is worth: **two of the three items it named do not cost what
it said, and the thing that does cost was not on the list.**

One edit on a 300-scene story, timed to paint, median of repeated runs:

```
everything open .................... 80.6 ms
Content panel collapsed ............ 66.8 ms   panel:      13.8
+ Inspector collapsed .............. 66.5 ms   inspector:  ~0
+ Story Graph collapsed ............ 33.3 ms   graph:      50.2
```

33 ms is the floor — two animation frames, which the measurement has to
wait for. So **the Story Graph was about 50 ms of an 80 ms keystroke**,
more than everything else put together, and nothing in the audit pointed
at it.

**The graph rebuilt every node and edge on every edit.** FlowPanel's memos
are keyed on `project`, and React Flow diffs by reference — so renaming one
scene handed it 300 new node objects and, on a story with choices, several
hundred new edge objects, every one of them reconciled. Unchanged nodes and
edges keep their identity now, decided by a signature built from the
primitives each one draws. On a story with 450 choices in it the graph went
from 81.9 ms to 58.3, with the node half worth about another 11.

**Item #22 does not exist.** The audit reported an unthrottled
`<input type="color">` in the Inspector. There is no colour input in the
Inspector: it uses the shared `BoxControls`, and that component was already
rAF-throttled in v0.49.0 — so fixing the Choice Styles half fixed this half
too, and the note in `claude/audit-v0.48-outcome.md` saying otherwise was
wrong.

**Item #24 costs nothing measurable.** Sixteen choice options on screen
were reported as 4,800 scan steps per keystroke. Measured as a delta
against the same scene without them: **−3.0 ms**, which is noise. The
related claim that walking every scene's choices costs 24.8 ms at 300
scenes does not reproduce either — it is **0.2 ms** for 300 scenes and 450
real choices.

**Item #23 is real, and the fix for it was aimed at the wrong half.** The
Content panel does cost about 16 ms of a keystroke. The audit blamed each
folder row filtering and sorting the whole node list, so that was replaced
with a prepared index — and the cost did not move: 16.5 ms with the index,
16.7 ms without. The filter was never where the time went; 300 rows
re-rendering is. The index was reverted rather than shipped as a fix for
something it does not fix. **Memoizing the context and the rows is the real
fix and it is a bigger refactor — it is not done, and it is the one tier-3
item still open.**

**Three findings about measuring.**

*The harness lied twice before it told the truth.* The first version
measured everything-open, then collapsed a panel and measured again. Across
runs the same build gave −7.9 ms and then +17.2 for the same difference:
±25 ms of drift on an effect worth 14. Alternating the two and taking the
median of paired differences cancels drift that is slow compared to one
pair, and the numbers went from that spread to ±1 ms.

*A toggle that silently misses makes everything after it meaningless.* The
expand controls are titled "Expand …", not "Show …". The clicks found
nothing, returned false into a variable nobody checked, and every later
measurement was taken with the panel still shut — reporting a tidy 0.1 ms
for a panel that had never been reopened. It throws now.

*Some things cannot be guarded by a clock.* The graph resolves to about
±10 ms over three paired runs, and the fixes are worth 24 and 11, so no
threshold separates them: tight enough to catch the regression is tight
enough to fire on a busy box. The timings stay as documentation and as a
gross-regression check — and they say so out loud when the machine is too
loaded to judge, because a red build meaning "CI was busy" teaches people
to ignore red builds. What the fix actually *does* — hand back the same
object when nothing changed — is asserted directly instead, and that has
the same answer on any machine.

473 tests, 55 negative controls.

---

## v0.50.0 — Getting around without a mouse

The v0.48.0 audit's tier 4. Every claim in it was reproduced against the
running app before anything was touched, and two of them turned out to be
worse than reported.

**The Content panel answers to a keyboard now.** The "Story" header, both
category headers and every character row were bare `<div onClick>` — no
role, no tab stop, no key handling. Measured: `{"tag":"DIV","tabIndex":-1,
"role":null}`. A writer navigating by keyboard could collapse "Story" and
then **never reopen it**, and could never open a character page at all.
That is a dead end rather than a rough edge, which is why this went before
the remaining performance work.

They stay divs, because they are drag handles and a native `<button>`
inside a draggable ancestor can swallow the mousedown Chromium needs to
recognise a drag. What was missing was everything else, and it is one
shared helper now rather than four hand-rolled copies.

**The focus ring was being drawn in transparent.** Tailwind's
`focus:outline-none` compiles to a 2px outline coloured `transparent` at
specificity (0,2,0); the app's global `:focus-visible` rule is (0,1,0). So
both matched and the invisible one won. Measured on a focused tree row:
matches `:focus-visible`, `outline-width: 2px`, `outline-color: rgba(0, 0,
0, 0)`. A ring, at full width, in nothing.

Removing the class was not the fix, and the test said so: a real click then
painted a ring on every row. `:focus-visible` settles this by itself for
native controls, but Chromium keeps matching it after a pointer click on a
`div[tabindex="0"]` — so the app had been choosing between a ring on every
click and no ring at all, and had chosen none. The modality is tracked
instead, which is what was always meant: pointer in use, no rings; a key
that moves focus, rings.

**Dialogs are dialogs.** `role="dialog"`, `aria-modal`, an accessible name,
focus moved in on open, Tab kept inside, and focus returned to whatever
opened it on close. Before this, opening a dialog left focus on the button
underneath the backdrop and Tab walked the application behind the scrim —
every control reachable, none of them visible.

**The Inspector agrees with the canvas about who is in the scene.** A
mention stores the label that was TYPED, and every reader is supposed to
resolve it through the entity list. Two in the Inspector did not, so a
renamed character kept her old name there while the graph, Check Story and
the export all showed the new one. The audit named one of them; measuring
that one found the second.

**Section labels settled on one spelling.** There were three type ramps
doing the same job across 33 headers, with the weight drifting between
semibold, medium and unset. They are one class now, at 10px with wider
tracking — chosen on the argument that a section label is not content, and
at 12px it is the same size as the values underneath it and competes with
them. Four inline tags that sit BESIDE text rather than above a group were
deliberately left alone, as were the vertical rail labels and the canvas
group-name input.

**The palette walk covers thirteen surfaces, up from four.** Export,
Project Settings, entity pages, Find results, the context menu, toasts, the
conflict dialog, Play Mode and the Welcome screen had never been looked at
by the audit that exists to look at them — which is why the `--overlay`
misuse on the writing surface survived four versions. Two things came out
of switching it on: the theme picker and the export's ground swatches are
now marked as content colour, because painting colours that are not the
current palette is precisely their job; and the walk learned that a palette
token at reduced opacity is still that token.

**Three findings about the tests, all of them mine.**

The walk's first attempt at "this colour without its transparency" painted
the colour over itself forty times and let it converge. Every pass
quantises to 8 bits, the error accumulates, and it settled two to four
units off per channel — nine units of distance against a tolerance of
eight. It passed on six themes, because their accent is near-white and sat
within tolerance of `--text`, and failed only on the two themes whose
accent is a distinctive colour. **A check that agrees with you except where
it is actually being tested is worse than no check.** It solves the alpha
from two composites now, with no accumulated rounding.

The two Inspector checks called the shared utility directly and passed the
resolver themselves — testing that the resolver works, which was never in
doubt, and saying nothing about whether the Inspector passes one. Both
negative controls went uncaught. They read the rendered panel now.

The section-label check queried the class it had just applied, so the
control that stripped the class from one header simply removed it from the
sample and the survivors still agreed. **A drift detector that only looks
at things which have not drifted cannot detect drift.** It measures every
uppercase micro-label on screen.

And one about how specs share an application: this one collapses sections,
and the Content Browser remembers which are open. Leaving them open made
the next spec — which clicks to open its own — close them instead and
report no cast. It hands the panel back the way it found it.

Two more controls were removed for passing honestly: the starting value of
the pointer-modality flag is a sensible default rather than a guarantee,
and both comments were reworded to stop claiming more than the tests show.

464 tests, 53 negative controls.

---

## v0.49.1 — The fix that didn't

Two data-loss bugs, both of them shipped **inside v0.49.0's fixes for data
loss**. Neither was found by the suite; both were found by reading the code
back afterwards and then measuring what it actually did.

**Closing the project did not flush what was pending.** v0.49.0 added
`await saveNow()` to `closeProject`, which reads exactly like a flush. But
`saveNow` begins with "a save is already on its way — queue and return",
and that branch returns an already-resolved promise having written nothing.
So the `await` waited for nothing; `closeProject` then cleared `saveQueued`
— the flag that call had just set — and nulled `filePath`; and the real
save landed afterwards, found the path had changed, and dropped the queue
too. Measured against a real file: save V2 in flight, type V3, close, and
the file holds **V2** while the store reports **"saved"**.

The window is ordinary, not exotic. Autosave fires 1.5 seconds after a
change, a write to a synced folder is not instant, and typing during that
second is what typing is.

The fix is `saveRun`: the promise of the save on its way *including* the
re-run it queues for anything typed while it was in flight. Returning that
from the early branch is what makes `await saveNow()` mean "the disk is
current" — which is what closing, quitting and Ctrl+S all assumed it
already meant, and what nothing had ever guaranteed.

**The close handshake gave the writer four seconds to answer a question.**
The main process destroyed the window four seconds after asking the
renderer to get ready. That clock was racing two things it had no business
racing. The one question this app asks — *"Close without saving?"*, about
an hour of work — resolves when the writer clicks it, so **reading it
carefully was the failure mode**. And a flush on a synced folder can exceed
four seconds by itself; v0.47.0 added EPERM/EBUSY retries precisely because
sync clients and scanners hold files open.

The timer is a liveness check now, not a deadline. The renderer sends a
pulse while it is working and the timer restarts on each one, so what it
measures is what it was always for: a renderer that has stopped responding
cannot make the window unclosable. A renderer that is busy, or waiting on a
person, is not that. The listeners are also removed by name rather than
left registered when the timer wins a race.

**What this says about v0.49.0**, which is the part worth keeping: that
release fixed six ways to lose work and added a regression test for each,
and two new ones went out in the same diff. Tests written alongside a fix
tend to test the shape the fix has, not the shape the bug had — v0.49.0's
save tests exercised the *stamp* during a save in flight, and never the
*close*. Reading the diff back, cold, found both of these in an afternoon.

**And three findings about the tests.** One negative control passed because
its sabotage was overwritten a line later, which meant the ordering it was
defending in `closeProject` is not the mechanism — `saveRun` is — so the
control is gone and the comment that claimed otherwise is corrected. And
the new close spec's own fixture spread a *closed* project's `null` into a
new one, leaving a project with no scenes: the checks still passed, because
saving nonsense is still saving, while the app rendered over something that
could not exist. That fixture made a whole half of the spec unreachable —
zero heartbeats, no error — and broke every spec that ran after it, since
specs share one application. A spec that leaves the app in a bad state
doesn't fail; the next one does, somewhere else, for reasons that look
nothing like it.

449 tests, 39 negative controls.

---

## v0.49.0 — A pass with the lights on

No new features. Five agents read the whole app looking for things that
were wrong, every extraordinary claim was checked by measurement before it
was believed, and the confirmed ones were fixed. The findings are in
`claude/audit-v0.48.md` in full; what follows is the part a writer would
notice.

**Six ways the app could lose work.** They share a shape, which is why
they survived seventeen versions: each one is a correct-looking line whose
failure needs two ordinary things to happen in the wrong order.

Switching scenes used Tiptap's `setContent`, which is a *transaction* on
the editor — so the swap went into ProseMirror's undo stack, and Ctrl+Z
after clicking a scene rebased the previous document's steps through the
new one. The fix replaces the whole `EditorState` rather than editing the
one that is there (`utils/loadDocument.ts`), which is the only operation
that has no history to rebase. The same effect reached the load itself:
the effect was keyed on `scene.id`, so a conflict reload that replaced
every scene in place left the open editor showing the old prose and the
next keystroke wrote it back over the file that had just been recovered.
It is now keyed on `${documentToken}:${scene.id}`, and the token moves on
every open, new, close and reload.

Structural undo restored `scenes` but not `entities`, so undoing a scene
delete also discarded everything typed on a Character page since. A late
save stamped whichever project was open when it *finished* rather than
the one it was written for, so switching projects during a save left the
new project holding the old one's file stamp — and the next save's
conflict check compared against a stranger. Closing a project cancelled
its pending write outright: 1.5 seconds of typing, gone, silently, at the
one moment a writer has most reason to assume everything is on disk.
`closeProject` now flushes first.

**The backup is a rotation, not a single file.** The one that mattered
most: "overwrite it with my version" wrote its backup to the same single
`.bak` that the routine five-minute cadence uses, *and* reset the cadence
clock — so the next autosave, triggered by nothing but continued typing,
copied the writer's own file over the other machine's work. The one undo
of last resort deleted itself on a timer. Three slots now (`.bak.1` newest),
so a version has to be pushed out by three later ones rather than replaced
by the next.

**Export can no longer land on the project file.** The export dialog opens
in the project's own folder, so the `.scriare` is right there in the list,
and clicking a file in a native Save dialog fills the name box with it.
Any extension was honoured verbatim, with no conflict check and no backup;
the story was replaced by a web page, atomically and completely, and the
app's next act was to offer "Open it". A project extension is never
honoured now, and anything that is not already a web page gains `.html` —
which also fixes `My Story v1.2`, whose `path.extname` is `".2"`, saving
with no extension at all under the old guard.

**Ten things that did not work.** Closing the window discarded unsaved
work with no prompt at all — there was a handler, but `beforeunload` in
the renderer is not what Electron asks; it is a main-process `close` event,
and the main process was not listening. Delete and Ctrl+Z reached the
story behind an open dialog. Creating, duplicating, pasting or deleting a
scene while a Character page was open left both selections set, and the
tree switched to the new scene while everything typed still went into the
character. Find could not match a query containing a space, because the
folding that makes search accent- and case-insensitive trimmed each
character individually and deleted the space between words. A folded
chapter only hid the scenes inside it if its box had been dragged by hand.
Escape did not close the slash-command or mention menus. Toasts rendered
*behind* modals. Opening Export twice showed the previous export's success
screen, one click away from opening a stale file.

**Eight measured performance findings, four taken.** The graph rebuilt
every edge on every selection change and did a linear scan per scene to
find its group — both now derive from one memo over the project. The
minimap re-rendered on every React Flow store tick because its selector
returned a fresh object literal. Dragging a choice's padding slider
re-serialised the document on every pointer event; it is throttled to a
frame now. The rest are in the audit doc with their measurements, deferred
rather than forgotten.

**What this version deliberately did not do** is change any behaviour a
writer chose. Every fix above restores something the app already claimed
to do. Tiers 3 to 5 of the audit — the remaining performance work, the
keyboard and screen-reader gaps, and the dead code — are recorded and
untouched.

**And a finding about the tests.** Three of the new negative controls did
not turn anything red. One sabotage was a no-op, one assertion was still
looking for the old single `.bak` name that the rotation no longer writes
under any circumstances, and one spec threw instead of failing when the
file it read was missing. All three were the test's fault, not the app's,
and all three were rewritten. The negative-control runner also now checks,
before it sabotages anything, that no earlier interrupted run left the
source broken — which had happened, and which nothing would otherwise have
noticed.

---

## v0.48.0 — The story as a page anyone can read

Export. One HTML file, playable in any browser, carrying everything the
writer formatted — and, first, a project file that finally says whose it is.

**Projects are `.scriare` now.** `.json` was honest about the format and
wrong about everything else: it sorts with config files, Explorer draws it
as a generic text document, and nothing about it says "this is my story".
The format has not changed and is not hidden — a `.scriare` file is still
JSON and still opens in any text editor. `.scri` was the shorter candidate
and lost on the argument that three letters save nothing anyone ever types:
the name is typed once, in a save dialog, and read a thousand times in a
file list. Every existing `.json` project still opens, permanently, and a
new story is offered a folder of its own in Documents — because a story is
not one file, it is the project, its `.bak`, and now the page exported
beside it.

**The export inherits the rich text editor's changes**, and that is not a
feature so much as a consequence of refusing to build a second renderer.
Prose goes through the same `resolveMentions` → speaker pass → Tiptap
pipeline Play Mode uses, so bold, italic, underline, headings, lists,
quotes, alignment, font family and size, hand-picked colour, highlight,
callouts, mentions resolved to their current names and speaker attributions
all arrive because it IS the renderer the writer was looking at. Choices
carry their styles, their conditions, their actions and their locked
reasons — the last of those written by the app's own `describeCondition`.

**Two reading grounds, not the app's eight themes.** A theme in Scriare is
chrome: forty-seven tokens tuned for a room with panels, borders and a
docked graph — "a theme tints the room, not the content". An exported page
has no room, and most of those tokens have nothing to refer to in it.
Shipping the writer's editor theme would publish whatever they found restful
at 2am to a stranger reading on a phone at lunchtime. So the export gets
**Paper** and **Night**, built for reading rather than for sitting beside
panels: Paper is a warm off-white rather than the Light theme's near-white
sheet, which only needs to out-bright a desk; Night is lifted well off black
because white on near-black at 15:1 halates on an OLED phone, and its body
text sits at 11.4:1, a long-read number rather than a specification-sheet
one. The reader switches between them and their choice is remembered; before
they have an opinion, the story opens on Night.

Every pair was measured before it shipped, and the first pass failed: Night's
tertiary text came in at 4.37:1 against a choice's fill — which is the text
carrying a locked choice's *reason*, the one thing a locked choice exists to
say. The whole ramp was lifted rather than that token nudged over the line,
because a value chosen to just pass a threshold fails the moment anything
around it moves.

**Colours the writer picked are content, so they travel unchanged — and the
export says so rather than fixing it.** A pale blue chosen in the Dark theme
lands on Paper as pale blue on off-white. The export dialog lists what may
not read, on which ground, with the measured ratio, and exports anyway: an
unreadable colour can be the point, and a tool that refuses to export a
deliberate effect has stopped being a tool. A choice style that was never
given a colour is written in theme variables, so it follows whichever ground
the reader chose and is never flagged.

**The reader gets Back, Restart, and their place kept.** Back undoes what a
choice did to the variables, not only where it went — otherwise you walk
back through a door keeping the key you picked up on the way out. A returning
reader is *offered* their place rather than dropped into it, because someone
reopening the file may have wanted to show a friend the opening.

**One file, no requests.** No font link, no stylesheet, no script, no image
host. It works offline, from a folder or a USB stick, and nobody learns who
read it. The cost is a system reading face instead of the app's Manrope —
the honest trade, since a webfont link would make an exported story's
typography depend on the network, which is the exact bug the app fixed in
itself by bundling its fonts.

Two things could not reuse the app's code, because a save dialog cannot ship
TypeScript to a browser: deciding whether a condition passes, and applying a
variable action. Those are transliterated by hand, and hand-transliterated
logic drifts into the worst failure this app has — a door that opens in Play
Mode and stays shut in the export, with nothing on screen to say so. They are
held to the originals by enumeration rather than by care: 966 condition cases
and 93 action cases, every type, every comparator, both polarities of
`negate`, every operation and a spread of wrong-typed values, run through
both implementations and required to agree. The exported file is written to
disk and opened in a real browser window to answer them, because the first
version ran it in a frame inside the app, where the app's own CSP blocked the
inline script and every assertion passed against a page whose behaviour did
not exist.

Three things review caught that the tests did not:

- **Export reused the project save path and brought the backup with it**, so
  exporting twice would have left a `My Story.html.bak` in the folder — a
  backup of a file that is itself a derivative.
- **The injection test was guarding a door that was never open.** It put
  `</script>` in a paragraph, where Tiptap had already escaped the `<`. The
  real hole is a scene *title*, which is copied into the embedded story data
  exactly as typed. Removing the escaping broke nothing until the test looked
  where it mattered.
- **A scene title with `</script>` in it, and two spellings of the same
  colour.** Each ground's page and text colour exists twice — as `oklch` in
  the stylesheet and as sRGB for the contrast check — so both are now painted
  onto a canvas and compared pixel to pixel rather than trusted to stay in
  step.

411 checks, and nineteen deliberate sabotages — a comparator off by one, an
action that subtracts, a Back that keeps the key, a ground switch that
changes the attribute and nothing else — each confirmed to turn the right
check red.

---

## v0.47.0 — Saving a project without destroying it

The save was one line: `fs.writeFile(filePath, json)`. That opens the
writer's real file, truncates it, and then writes — so from the first byte
until the last, what is on disk is neither the old version nor the new one.
Anything that interrupts it costs the file. Reproduced before touching
anything, on a filesystem with no room left:

```
before:  16719 bytes, parses: true
write failed: ENOSPC
after:  409600 bytes, parses: false
```

A 16KB story became 400KB of half-written JSON, and the last good version
was already gone. A full disk, a quota, a synced folder out of room, a
laptop losing power, a process killed mid-save — the same accident wearing
different clothes.

**A project file is now replaced, never written into.** The new version goes
to a temp file beside it, is flushed to the platter, and is renamed over the
target. A rename inside one directory is atomic: readers see the old file or
the new one, and a failure at any earlier step leaves the old one exactly as
it was.

**The version being replaced is kept**, as `<project>.bak` — but on a
cadence, not on every save. Autosave fires 1.5 seconds after every change,
and a backup from 1.5 seconds ago is the same mistake you just made; every
five minutes gives you a version from before the thing you regret. The one
exception is overwriting a conflict, which always keeps what it destroys.

**A file that changed underneath us is not overwritten.** The app remembers
which version it opened and asks before replacing anything else: reload,
save yours as a copy, or overwrite deliberately. Nothing is written while
the question stands, and no save is even attempted behind the dialog.

Three more defects turned up while reviewing this work, none of them in the
original plan:

- **Two saves could run at once** — Ctrl+S while autosave was in flight —
  and they collided. Both generated the same temp filename (same process,
  same millisecond), so one rename took the file and the other failed with
  ENOENT; the save the writer asked for was the one that lost. Temp names are
  now unique per write, and saves are serialised, with a single re-run queued
  if anything changed while one was in flight. Without that, the older save
  could also land last and quietly put back a chapter you had just cut.
- **A failed save said nothing.** The status stopped at "Saving…" and stayed
  there — the one moment a writer most needs to be told something, told
  silently. It now names what happened ("there is no room left on the disk")
  and says plainly that the work is still open and the last saved version is
  intact. Once, not once per autosave.
- The fallback file size counted characters rather than bytes, which is
  wrong the moment a story contains a single Turkish character.

28 tests, every one of them confirmed to fail on a build with the old
behaviour put back — including three assertions that had to be rewritten
because they passed against the bug they were written for. The first watched
a save in flight and asserted it never saw a half-written file; what it was
actually measuring was how long the JSON takes to cross the IPC bridge.

---

## v0.46.0 — A theme audit, and the four things it found

No new features. The app was walked in all eight themes, on every surface it
can open, looking for colours it paints that do not come from the palette —
because a hardcoded colour is theme-blind by definition: it looks deliberate
in whichever theme it was written against and wrong in the other seven.

**Check Story's warnings were Tailwind's amber**, a literal colour with no
relation to the palette. On a dark ground it reads; on the four light and mid
grounds it is nearly invisible — so on half the themes the app's own "look at
this" mark was the hardest thing on screen to see. There is now a `--warning`
token, the third of the meaning colours beside `--danger` and `--success`,
tuned per ground the way those are.

**The ending card in Play Mode was painted with `--overlay`** — the scrim
drawn *behind* a dialog, used as a surface. On the dark themes that passes for
a slightly darker panel; on the light ones it is a heavy grey slab across the
page. An ending is a panel on the page, and panels are surfaces.

**Two controls outlined themselves in black** regardless of theme — the
toolbar's colour chip and the theme swatches in Settings — and **a drag
preview in the Inspector carried the dark theme's shadow written out by
hand**, which on a light ground reads as dirt on paper. All three now use the
tokens that exist for exactly this.

Also removed: opacity modifiers on `var()` colours (`border-[var(--danger)]/50`
and friends), which Tailwind cannot compute and silently discarded — a fade
that was never on screen in the first place.

**The audit is now a test**, run on every surface in every theme, with the
two things that are legitimately off-palette marked as such: the toolbar's
colour and highlight bars, which *are* the colour they show. Confirmed by
putting the amber back — all eight themes report it.

One thing deliberately not fixed: the Story Graph's connection handles are
drawn by React Flow in its own navy-and-white, but they are `opacity: 0` in
this app — nobody drags a wire here, connections come from the writing — so
theming something invisible would have been a fix for nothing.

---

## v0.45.0 — One control for folding a panel away

**The dock toggles are the same control now, in all eight themes.** Reported,
and it was two faults wearing one symptom. The three dockable panels —
Content, Inspector, Story Graph — had each grown their own version of the
same button: three different glyphs at three different sizes, one of them
baked into a header label that was itself the button. On top of that, the
Content panel's ghost buttons were being drawn as raised boxes while the
identical control one panel over stayed flat text, so the two did not even
look like the same KIND of thing.

That second half was a CSS bug from v0.40.0's elevation pass. The rule that
lifts a selected row matched the Tailwind class that paints it — and a
Tailwind variant's class name contains the base name, so
`hover:bg-[var(--surface-2)]` matched too, and every ghost button in that
panel that merely lit up on hover was permanently drawn as a raised object.
The rule now keys on a class the row sets for the purpose.

The toggle itself is one component: a real bordered button, 22px square, same
radius, border and fill everywhere, with the chevron DRAWN rather than typed
— a glyph like ◂ is a font's opinion, and its weight and baseline differ
between the faces the app falls back to, which was half of why the three
never matched. A collapsed strip shows the same box, because the control you
click to fold a panel away and the one you click to bring it back should be
recognisably the same control.

**And it has room.** The Content toggle was the third item in a row of three,
hard against "+ Group"; it now sits apart from them, because folding a panel
is a different kind of act from making a scene. The Story Graph's sat
directly under the splitter, all but touching the editor above it, and now
has a proper margin.

The tests measure the three against EACH OTHER, in every one of the eight
themes, rather than against numbers written into the test — so this cannot be
satisfied by three controls that happen to match on the day they were
written.

---

## v0.44.0 — Eight themes, and a page that behaves like paper

**Six new themes.** Daylight (paper and sepia ink, the lightest), Overcast
(a mid slate, where the page is the only bright thing in the window),
Lamplight (dark and warm, amber), Deep Water (dark and cold, cyan), Nocturne
(violet and rose) and Phosphor (terminal green). Colour lives in the ground,
not in the content: a theme tints the room, and the accent — which only ever
marks selection, focus and the primary action — is the one piece of chrome
that carries a hue of its own. The picker in Settings shows all eight at
once, each swatch drawn in its own theme's tokens, because a theme is chosen
by looking and a list you scroll turns that into a memory test.

**Dark and Light are polished rather than replaced.** Dark gets a deeper
floor (9.5%, from 11%) so panels and the page have something to sit above;
its --border-soft now sits above --surface-2 instead of below it, so a soft
border actually divides rather than disappearing into what it divides; and
the warmth the theme has always claimed in its own comments is finally
perceptible rather than a rounding error away from pure grey. Light's desk
steps back so the page can be the brightest thing on screen.

**The page is a sheet on a desk again.** It was drawn in --surface, which on
a light theme is DARKER than the ground it lies on — so the paper was dimmer
than the desk, backwards for the one metaphor the whole elevation pass is
built on. Every theme now sets --page, a step from --bg toward the light.

**Captions got legible.** Measuring the palettes rather than looking at them
turned up that --text-3 — the status bar, every hint and caption, at eleven
pixels — was under 4.5:1 in the shipping Light theme and in five of the six
new ones. All eight now clear it where they are read, and the suite measures
the real ratios from what the browser paints rather than trusting the
numbers in the stylesheet.

The eight themes and their contrast floors are covered by tests: every theme
must define every token the default one does (a missing one silently
inherits and nothing says so), must paint a different ground, must keep its
page lighter than its desk, and must keep its borders far enough from what
they divide to be visible at all.

---

## v0.43.0 — A map that reads left to right

**Auto Layout arranges the story, not the diagram.** Reported as "it tidies
up the space but seems like not enough", and the cause was the ranking: dagre
minimises total connection length, which is right for a flowchart and wrong
for a story. Given a scene with three choices it was free to put each option
in a different column so the long branch and the short one met neatly at the
merge — three options from one moment marching down and to the right, with
not one of their connections horizontal.

A scene now sits one column past the scene that leads to it, so every choice
out of a scene lands in the same column: the trunk runs straight across, a
branch is a vertical fan at the moment it happens, and a column means
something you can read — how far into the story this is. On top of that, a
scene whose feeders all sit on one line joins that line, which is what turns
a spine of four scenes from a gentle zig-zag into one straight row. A merge
point is deliberately left where it is, between the branches it merges,
because a merge that snaps onto one branch lies about the others.

Columns and rows are also closer together — 108px and 36px, both whole cells
of the canvas grid.

**A connection says which choice it is.** Every wire now carries "Choice 1",
always, instead of a bare ordinal that turned into the choice's full sentence
under the pointer or on a selected scene. The sentence is one double-click
away in the scene itself, and a label that rewrites itself as the pointer
moves is a label you have to chase. Pulled far enough out that the text would
be a smear along the wires, it is left off entirely.

**Folding a chapter no longer resizes it.** Reported: fold a group, move it,
unfold it, and the box came back the size of the little folded block with its
own scenes sitting outside it. A box's drag was writing the size it was DRAWN
at, and a folded box is drawn as a fixed small block while still owning the
dimensions it will unfold to. A drag moves a box; only a resize resizes one.

**And a box no longer shrinks by a pixel or two every time it is moved.** The
grid snapped every rectangle by its corners, which is right for a resize and
wrong for a move: the origin and the far edge round independently, so sliding
a 620x300 chapter sideways quietly made it 612x306. Whichever gesture is
happening decides the rule.

---

## v0.42.0 — The canvas has lines

**The Story Graph is grid-based.** Movement, landing and resizing all obey
an 18px lattice — the same spacing as the canvas's fine dot field, so a
card comes to rest on a dot rather than on an invisible rule. A story laid
out by hand now lines up the way one laid out by Auto Layout does, without
anyone nudging anything by a pixel.

Four routes reach the canvas and all four had to agree, or the grid would
read as a rendering bug rather than a rule: a dragged card (which steps
from cell to cell while the mouse is still down, not on release), a resized
box, Auto Layout's output, and any position written straight to the store —
which is how a pasted scene or a project file from before the grid arrives.
A box is snapped by its corners rather than by its origin and size, so the
edge you dragged lands on the line nearest where you left it.

**Holding Alt suspends it**, for the one thing a grid cannot do: put a card
exactly where the grid has no line.

**Also fixed:** a scene that left the canvas — deleted from the Content
Browser, or carried off with a project that was closed — stayed selected,
with nothing on screen saying so and Delete still pointed at it. Found while
testing the grid; what is selected is now always a subset of what exists.

---

## v0.41.0 — A bar at the bottom, a floor under the graph

Five things, all reported while using v0.40.0, and none of them changes how
anything behaves.

**The window closes the way it opens.** The top of the three columns is a
single unbroken line; the bottom was three different edges at three
different heights, because each column ran out of content wherever it
happened to. There is now one bar across all three. It carries what a
writer glances down for: how big the story is, which scene is open and how
long it is, and whether the map is showing. The word count is the open
scene only — a project-wide count would mean walking every document on
every keystroke.

**The Story Graph has a floor.** Two dot fields instead of one flat grid: a
fine one that gives the canvas a surface, and a coarser, brighter one that
gives it a scale. Reported as "the graph feels infinite and hard to read",
which is exactly what a canvas with no measurable spacing feels like —
without the second field, panning reads as texture sliding past rather than
as movement over something.

**The Story Graph can take the whole column.** The splitter's ceiling was a
hard-coded 640px, so the map stopped at roughly two thirds of the window.
It is now the column's own height, measured at drag time: drag all the way
up and the editor retracts completely.

**More lift.** Every elevation token is heavier and two-layer, controls went
up a step — they were the half still reading as flat — and a selected row
or the active scene card now catches a faint ring of the accent as well as
casting a shadow. The page gained a third shadow layer and a lit top edge,
so the sheet has a rim rather than sitting on a dark rectangle.

**The side panels separate by light, not by shadow.** They now carry a
single lit pixel down their inner edge instead of casting into the editor —
the same reason the inward cast was removed in v0.40.0, applied as a
replacement rather than an absence.

## v0.40.0 — Lifted

A finish pass, chosen from four mockups. Nothing moves, nothing is added,
nothing behaves differently: every change is a shadow, a lit edge, or the
padding of the new page.

**The writing surface is a page.** A sheet with its own edge and shadow,
sitting on the desk, rather than text lying directly on the background. Its
width is the reading column plus exactly the margin it adds, so the line
length a writer sees is unchanged — and on a narrow window the margin
narrows rather than shortening the lines.

**Controls read as made objects.** Anything that already drew a border —
the font and size pickers, the Choice group, the top bar's buttons, the
Inspector's fields — gets a single lit pixel along its top edge and a
shadow beneath. Ghost icon buttons stay flat on purpose: that contrast is
what makes the difference legible.

**Selected things rise.** A selected row in the Content Browser lifts
instead of only brightening, and a scene on the graph is a card on a table.
Group boxes stay flat — a container that casts a shadow looks like it is
sitting *on* what it is supposed to hold.

Elevation is a token set with separate values per theme, because a
dark-theme black shadow on a light-theme page reads as dirt.

One thing was tried and removed: the side panels casting inward onto the
editor. It was worth about two levels of grey, and it dimmed the first
thirty pixels of the toolbar's bottom border, so the border stopped
visibly short of the Content Browser's edge and that corner read as
unfinished. Reported, measured (3/255 against 5/255 across the rest of the
line), and deleted. A wall is defined by its line, not by its shadow.

## v0.39.2 — The third group on the canvas stopped eating clicks

Reported: the scenes inside the **Endings** group couldn't be opened — a
click selected the group instead — while the other two groups and
everything in them behaved.

Nothing about that group was special. A group's stacking order was its
place in the parents-first group list, so that a box nested inside another
paints above the one that owns it; a scene's was the literal 1. The first
box (0) sat behind its scenes, the second (1) tied and lost to them, and
the **third (2) and everything after it** was drawn over its own contents
and swallowed every click. A box is a container, so it now always sits
behind what it contains, whatever order it was made in.

Four tests, two of them measuring the reported sentence directly: what is
under the pointer at a scene's centre, and which object a real click
selects. Both come back naming the group on a build with the fix removed.

## v0.39.1 — The Story Graph's connections are visible again

Every connection printed its choice's full sentence across the curve. On a
thirteen-scene story that made the map unreadable: the sentences overlapped
each other and sat on top of the wires they belonged to, so the one thing
the graph exists to answer — which scene leads where — was the one thing
you couldn't trace.

A wire now carries its choice's **number** instead, a small bead on the
cable, numbered by the option's place on the page — so an unlinked option
keeps its number rather than silently renumbering the rest. The text
appears where you are already looking: **point at a wire** and that one
choice is named, at any zoom, drawn at a fixed size on screen so it is
readable even when the whole story is on the canvas; **select a scene** and
its own wires carry their text, once the camera is close enough for an
11px label to be legible. Nothing was removed; it just stopped all being
shown at once. Bundled connections between folded groups read `×3` at rest
and `3 links` when pointed at.

Also: the test runner now resets the editor/graph splitter along with the
panel layout. The graph fits its camera to the panel it is given, so a
splitter position left over from writing decided the zoom, and the zoom
decided how many screen pixels a node occupied — which quietly changed what
the Group-rename drag test was measuring. Same leak as the seven
one-machine failures in v0.38.1, one key further along.

## v0.39.0 — Deleting, renaming, and a Group name you can select

Three things found by using the app. All the same shape: something built
and then not connected to the way a person actually reaches it.

**Characters and Locations can be deleted.** Right-click a row for Rename
and Delete, with the same undo toast a deleted scene raises. `deleteEntity`
had been in the store since v0.35.0, correct and undoable — its row simply
had no menu, so nothing in the interface ever called it. Deleting someone
still leaves every mention of her in the prose: the words stay as written,
the app just stops claiming they point anywhere.

**F2 renames.** A scene, a group, a character or a location — whichever the
Content Browser has selected. Focus decides whether the key is yours or the
text field's, the same rule Ctrl+Z and Ctrl+C already follow, so F2 with
the caret in a sentence does nothing. Delete now removes a selected
character too, and the panel holds one selection at a time rather than
leaving a scene lit up while a character row is the one you're acting on.

Renaming a character renames her *everywhere*, and there is no second
option, because there is nothing for one to mean: no sentence ever stored
her name. If she should be called something else in one place, that is an
alias, which the app has had since v0.35.0.

**A Group's name on the Story Graph can be selected with the mouse.**
Dragging across it moved the whole group. The field guarded `mousedown`;
React Flow drags from `pointerdown`, so the guard never saw the gesture —
and a plain click worked fine, which is what made it look like a
text-selection quirk rather than a drag. It uses React Flow's own `nodrag`
opt-out now, which checks the whole target chain.

Sixteen new tests. Two of them are the interesting ones. The first version
of the drag test dispatched its own PointerEvents, and both the assertion
and its control reported "nothing moved" — the drag had never started, so
the test passed for the wrong reason; it now uses a real mouse. The second
version then landed on a scene node sitting over the group, which looked
exactly like the bug, so the test now asserts what is under the pointer
before it presses. A hand-written `pointerdown` guard added along the way
was deleted when the control showed `nodrag` alone was doing the work.
244 tests.

## v0.38.1 — Fixed: the test suite measured the writer's own workspace

Seven tests failed on one machine and passed on every other. The cause
wasn't in the app: Electron gives an app one `userData` directory per app
name, so the test build and a real installed copy of Scriare share the
localStorage key that remembers which panels you collapsed. A writer who
had folded away the Inspector and the Story Graph to write ran a suite in
which seven assertions measured panels that were not on screen.

The runner now states the layout instead of inheriting it, before the app
mounts. But the seven failures were the *smaller* half of this. Three other
assertions had been passing **because** the panels were missing —
`.every()` over an empty list is true, so "every row is still" and "the
open row has its controls" were both satisfied by an Inspector that wasn't
rendered, and "a story that fits has no minimap" was satisfied by there
being no graph. Those now assert their own preconditions: four rows, one
open row, a visible graph.

A test that cannot tell "correct" from "absent" is worse than a missing
test, because it reports success. 228 tests.

## v0.38.0 — Find

Searching the Content panel now searches the writing: every line of prose,
every choice label, and every character and location page, grouped as
**In the story** and **On pages**. Clicking a result opens that scene with
the matched words selected. Turkish-aware matching, shared with the `@`
menu so the two can't disagree.

## v0.37.2 — Fixed: attributing a line you've already written

`@` at the head of a line now sets the speaker even when the line already
has words in it. The old rule required an empty line, which got the
commonest order of work backwards — you write the line, then say who said
it. Shift on confirm still writes the name into the line instead.

## v0.37.1 — Fixed: places were offered as speakers

A Location could be set as a line's speaker. Only a Character can speak
now, asked through one function (`canSpeak`) at every door. The `@` menu
still offers a place at the head of a line, marked as a mention.

## v0.37.0 — Speaker attribution

A line can know who is saying it: `@` at the head of a line attributes it,
Enter carries the speaker forward, Backspace drops it, clicking the name
changes it. Play Mode prints the name when the speaker changes. Choices can
carry a speaker too. Also fixed: a character mentioned inside a choice
label was invisible to the Story Graph, Check Story and the Inspector.

## v0.36.2 — Check Story, grouped by scene

Findings are grouped by the scene they're repaired in, with counts as
colour chips rather than prose. Unwritten choices are named by position
("choice 3") instead of repeating the editor's own placeholder.

## v0.36.1 — The minimap knows when to leave

The Story Graph's minimap now appears only when part of the graph is off
screen, and sits at a low opacity until the pointer reaches it.

## v0.36.0 — Check Story

A report of the story from the outside: unreachable scenes, choices that go
nowhere, links to deleted scenes, gates on deleted variables, endings,
route lengths and word count. Every line is a button that opens the scene
with the Inspector already pointed at what needs fixing.

## v0.35.1 — Fixed: the cursor giving away where the characters are

Mentions carried an unscoped text cursor, so the pointer changed as it
crossed a name in Play Mode. Every hint a mention gives is now scoped to
the editor; in Play Mode it inherits whatever surrounds it.

## v0.35.0 — Characters and Locations

Both are one object with two kinds: a name, the other names it answers to,
and a page written in the same editor as a scene. `@` mentions them by any
of their names, offers to create one that doesn't exist yet, and stores the
id — so renaming reaches every sentence, including in Play Mode. Matching
handles Turkish properly. Also: Play Mode's duplicate Exit button removed.

## v0.34.1 — Fixed: the Inspector closing while you use it

Reordering a choice threw the Inspector back to Scene Properties on mouse
release. A selection inside a choice now always opens it; a selection in
nothing only closes the panel when the writer moved it there themselves.
The same wrong assumption was also making a header click open and shut the
panel within one click.

## v0.34.0 — Choice Styles

Named styles — fill, border, thickness, radius — defined once in Project
Settings and worn by any choice, with per-choice overrides and a reset.
Choices are drawn in their style while writing, not only in Play Mode. A
colour set back to "Theme" follows light and dark mode.

## v0.33.2 — Fixed: choices flying in from the bottom of the Inspector

Opening choices top-down animated each one racing up the panel. The
animation now distinguishes a row that moved because something else resized
from a row that merely opened or closed.

## v0.33.1 — The panel follows the caret

The toolbar no longer grows six pixels when the caret enters a choice, and
the Inspector opens on the choice being typed in — on the option the caret
is in, not a list of summaries. A stale captured scene id in the selection
handler was the cause of the second half.

## v0.33.0 — The toolbar learns the language

Nineteen toolbar controls redrawn in the app's own icon set on the same
grid as the rest of the UI. B/I/U stay as letterforms; the colour controls
wear the colour they'd apply; a Choice group appends when the caret is
inside a choice. Nothing moved and nothing was removed.

## v0.32.0 — Choices are written, not configured

A choice's label became real inline content in the document rather than a
string in a hidden property, so the toolbar, undo, find and Play Mode all
reach it with no new code. Old projects convert on load, across two
generations of the previous shape.

## v0.31.1 — Folded means folded

A folded group no longer catches scenes dropped in the empty space it used
to occupy — hit-testing uses the rectangle actually drawn. Folding a group
now hides its sub-groups too.

## v0.31.0 — One word, both ways

A group created in the Content Browser now appears on the graph once it
holds a scene, and follows its scenes until first moved. "Folder" is called
"Group" everywhere a person can read it.

## v0.30.0 — Conditions

A choice can require a variable's state — variable, comparator, value, all
of which must hold, with a NOT toggle and no expression field. A failed
condition can hide the choice or lock it with the reason shown. Adds
Conditional Text for gating prose, and a read-only variable readout in Play
Mode.

## v0.29.0 — Auto Layout, all the way down

Auto Layout now arranges the inside of every group and resizes each one to
fit, running innermost-first so a nested chapter lands inside its parent.
One Ctrl+Z puts every position and box size back.

## v0.28.0 — One hierarchy

Frames were removed; a folder now owns its box on the graph. Renaming,
deleting, dragging and dropping on the canvas all reorganise the tree,
because they are the same object. Groups fold, bundling crossing links into
one labelled edge, and nest to any depth. Old projects convert on open.

## v0.27.0 — Keys that work everywhere

Ctrl+C / X / V and Delete work on scenes and folders, routed by focus the
same way Ctrl+Z is. The panel touched last owns the keyboard. Copying
linked scenes gives you the branch — the copies link to each other, while
links out of the copied set still point where they did.

## v0.26.0 — Undo, out loud

All five delete confirmations replaced by an undo toast, since a modal
earns its interruption only while the mistake is permanent. The toast drops
its button the moment its history step stops being the one undo would
reverse. Tests became a first-class part of the project (`npm test`).

## v0.25.0 — Undo

Project-wide undo/redo for every structural action, snapshot-based and
cheap because the store never mutates in place. Undo never rolls back
prose: structure and words have separate stacks, routed by focus. One
gesture is one step.

## v0.24.0 — A quieter, better-built monochrome

Three causes behind "it feels dull", two of them bugs: the Content Security
Policy had been silently blocking Google Fonts and the logo in every build,
and the greys were chroma-0 with a tonal ramp too even to read as
hierarchy. Also: emoji removed from the chrome, minimap muted, light
theme's editor made readable.

## v0.23.4 — Fixed: measurements taken mid-animation

In-flight animations are settled before measuring; mid-transition reads
were producing negative spacing and wrong drops.

## v0.23.3 — Fixed: choices sliding behind the landing zone

Paint order corrected so choices always render above the landing
placeholder.

## v0.23.2 — The dragged choice looks as lifted as it is

A border and layered shadows on the floating card.

## v0.23.1 — Fixed: the jolt at the moment of release

A stale baseline made a dropped choice replay an animation of a move that
had already happened.

## v0.23.0 — Drag reordering rebuilt on a layout that doesn't move

The list is frozen for the whole gesture and choices move by transform, so
the geometry a swap decision reads can no longer be changed by that
decision. Threshold tuning replaced by nearest-landing-zone matching.

## v0.22.12 — Fixed: downward-drag overshoot

Overshoot fixed by comparing cursor edges; a visible landing zone and a
commit delay added.

## v0.22.11 — Fixed: reorder dead zones

Dead zones fixed by comparing near edges; sibling positions frozen at
drag-start to stop oscillation.

## v0.22.10 — Removed the drop catch-up animation *(superseded)*

An unconfirmed guess at a reported collapsing-choices bug. The bug survived
the release.

## v0.22.9 — Scroll-anchoring disabled *(superseded)*

Browser scroll-anchoring was blamed for sliding choices. The premise was
wrong and the fix did nothing.

## v0.22.8 — Choice spacing made structural *(superseded)*

Margins replaced by flex gap — a real structural improvement that didn't
touch the reported symptom.

## v0.22.7 — Content-aware drag bounds *(superseded)*

Fixed clearance replaced by one derived from live sibling edges. Fixed that
issue, not the one reported next.

## v0.22.6 — Fixed: last slot unreachable when dragging

A full-card-height clearance replaced by a small fixed one, so every slot
can be reached.

## v0.22.5 — Smooth drop and bounded drag

A stale-state jolt on drop fixed with refs; dragging clamped to the panel's
bounds.

## v0.22.4 — Top-edge drag reordering

The reorder trigger compares top edges rather than card centres, so the
swap point stops shifting with what's expanded.

## v0.22.3 — Fixed: stuck gaps between choices

Transforms reset before measuring; drag cleanup hardened against
interrupted gestures.

## v0.22.1 — Choice Block Inspector refinement

Drag overlay made purely cursor-based, inline "Create Scene / Variable"
added, choice creation restored to the block editor.

## v0.22.0 — Choice Block Inspector refactor

Every choice edit, from the Inspector or the editor, now goes through one
real ProseMirror transaction — the previous path wrote to the saved project
without the live editor seeing it.

## v0.21.0 — Runtime foundation and variables

Typed variables and an Inspector-driven Actions system, so a choice can set
or toggle a variable with no syntax anywhere. Scene Details became the
adaptive Inspector.

## v0.20.3 — Bold and code no longer hide text colour

Tailwind Typography's hardcoded colours forced to inherit.

## v0.20.2 — Text-colour reset inside lists

Resetting colour inside a list no longer strips font and size with it.

## v0.20.1 — Toolbar selection-loss fix

Toolbar clicks were stealing the editor's selection, so controls read a
stale, collapsed cursor.

## v0.20.0 — Styled list markers

Bullets and numbers take the list item's colour, font and size.

## v0.19.2 — Reset text colour and highlight

Reset buttons beside each picker, so either can be cleared without Clear
Formatting.

## v0.19.1 — Colour picker drag performance

Per-pixel change events coalesced into one editor update per frame.

## v0.19.0 — Existing features evaluation

The New Project dialog rebuilt on the shared Modal shell; fifteen other
systems evaluated and deliberately left unchanged.

## v0.18.0 — Desktop identity

Electron's default menu and branding removed, the app's real name set, and
destructive-button colours matched to the theme token.

## v0.17.0 — Story Graph interaction feel

Eased drag lift, a crosshair over empty canvas, hover on resize handles,
and selection-driven edge highlighting.

## v0.16.0 — Frames in Auto Layout

Frames participate in Auto Layout as their own node, moving as a unit while
their contents keep their arrangement.

## v0.15.1 — Story Graph interaction fixes

Multi-selected nodes move together; a redundant bounding box removed;
laggy top and left resize handles fixed.

## v0.15.0 — Story Graph interaction polish

Right-drag to pan, left-click to select, box-select — the scheme node
editors use. Live frame resizing, and a selection ring distinct from
opening a scene.

## v0.14.2 — Frame selection fix

Frames lost selection on every redraw; selection became explicit app state.
Connectors switched to bezier curves.

## v0.14.0 — Graph interaction evaluation

Frames given the lift, selection border and hover feedback scenes already
had; edges highlight with the selected scene.

## v0.13.0 — Real logo

The typographic placeholder replaced by the finished mark — theme-aware in
the app, fixed dark for the OS taskbar.

## v0.12.1 — Lighter light mode

Light mode's background and surfaces shifted from near-white to a light
grey, with every contrast step unchanged.

## v0.12.0 — Minimal

Four colourful themes replaced by black/white/grey Dark and Light, with
colour reserved for meaning. UI font switched to Inter.

## v0.11.2 — Dockable panels polish

Collapsed-strip labels unified with the Story Graph's styling.

## v0.11.1 — Dockable panels polish

The collapsed bar clickable anywhere, collapse icons unified, Scene
Details' toggle moved beside the page.

## v0.11.0 — Dockable panels

All three panels collapse to thin strips, and the layout is remembered
across relaunches.

## v0.10.6 — Minimap refresh fix, part 2

v0.10.5's fix had a missing dependency, so the counter never forced the
recompute it existed for.

## v0.10.5 — Minimap refresh fix

The minimap showed colourless boxes until something was dragged.

## v0.10.4 — Drag freeze fix

Each node's measured size is cached, so it survives being rebuilt as a new
object every frame.

## v0.10.3 — Drag performance fix

Choice counts and edges memoized on content alone, making per-frame drag
updates pure arithmetic.

## v0.10.2 — Drag fix, part 2

Scenes follow the cursor via a live drag offset, the mechanism frame
dragging already used.

## v0.10.1 — Drag fix

Drag lift and drop-target highlights moved to CSS classes, so dragging a
scene no longer snapped back to its start.

## v0.10.0 — Graph interaction polish

A drop preview and lift state while dragging, eased hover and select
transitions, smoothed edge and camera-fit animations.

## v0.9.1 — Brand mark

The logo image replaced by a rendered letterform, so the mark re-themes
with the accent colour instantly.

## v0.9.0 — Premium redesign

Theming rebuilt on oklch CSS custom properties instead of hardcoded colour
classes, so a theme changes in one file. Newsreader paired with Manrope.

## v0.8.3 — Drag and drop fix

A `preventDefault` on nested buttons had been breaking Content Browser drag
and drop since v0.6.1.

## v0.8.2 — Regression audit

v0.8.0/v0.8.1 traced across drag and drop, selection, favourites, search
and graph sync. No functional regressions — though the audit traced code
rather than gestures, and missed the drag bug fixed in v0.8.3.

## v0.8.1 — Start Scene management

The Start Scene can be set from the Content Browser and the Inspector, with
exactly one kept in sync everywhere.

## v0.8.0 — Runtime polish

A settable Start Scene, an ending screen, Escape to exit, scene fades, and
Play Mode split into its own runtime layer with a per-block registry.

## v0.7.0 — Narrative blocks

Multi-option Choice Blocks, slash commands, and a Callout block — all
typed straight through, so paragraphs are still paragraphs. Play Mode
renders every block in document order.

## v0.6.2 — Play Mode reading-width fix

Play Mode shares the editor's reading-column definition, so text width,
wrap and typography match between writing and playing.

## v0.6.1 — Selection and layout fixes

A stray focus highlight on Shift+Click removed; scene connection points
moved to left and right so Auto Layout's edges route straight.

## v0.6.0 — Multi-selection and confirm dialogs

Ctrl/Shift multi-selection, multi-item drag and bulk actions in the Content
Browser, and in-app confirmation dialogs.

## v0.5.0 — Content Browser

A hierarchical drag-and-drop Story tree with folders, favourites and
search, built on a generic `ContentNode` so future content types need no
changes to the tree.

---

## Before v0.5.0

The project's written history begins at v0.5.0. Earlier versions are known
from references elsewhere in the notes rather than from entries of their
own: **v0.4.0** brought the writing toolbar and the resizable editor/graph
split, and **v0.3.0** brought Play Mode. They are listed here for
completeness rather than reconstructed in detail.
